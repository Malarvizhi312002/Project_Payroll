export class Employ {
    public empno : number;
    public name : string;
    public username: string;
    public password: string;
    public gender : string;
    public dept : string;
    public desig : string;
    public dateOfBirth : Date;
    public dateOfJoin : Date;
    public salary : number;
    public leaveAvailable : string;
    constructor() {}

}
