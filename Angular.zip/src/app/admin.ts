export class Admin {
    public Username : string;
    public Password : string;
}
