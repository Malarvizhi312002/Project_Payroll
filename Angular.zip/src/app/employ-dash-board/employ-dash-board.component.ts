import { Component } from '@angular/core';

@Component({
  selector: 'app-employ-dash-board',
  templateUrl: './employ-dash-board.component.html',
  styleUrl: './employ-dash-board.component.css'
})
export class EmployDashBoardComponent {

}
